#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ConectaEduca - Backend API
Sistema de apoio para o projeto ConectaEduca

Este arquivo Python fornece funcionalidades básicas de backend
para o aplicativo ConectaEduca, incluindo:
- API para dados estatísticos
- Simulação de cadastro de interessados
- Geração de relatórios básicos
- Validação de dados

Requer: Flask, json, datetime
"""

from flask import Flask, jsonify, request, render_template_string
from flask_cors import CORS
import json
import datetime
import sqlite3
import os
from typing import Dict, List, Any

app = Flask(__name__)
CORS(app)  # Permitir requisições cross-origin

# Configuração do banco de dados SQLite
DATABASE = 'conecta_educa.db'

def init_db():
    """Inicializa o banco de dados"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Tabela de interessados
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS interessados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            tipo_interesse TEXT NOT NULL,
            data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
            ativo BOOLEAN DEFAULT TRUE
        )
    ''')
    
    # Tabela de estatísticas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS estatisticas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metrica TEXT NOT NULL,
            valor INTEGER NOT NULL,
            data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tabela de eventos/analytics
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS eventos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            evento TEXT NOT NULL,
            dados TEXT,
            data_evento DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_origem TEXT
        )
    ''')
    
    # Inserir dados iniciais se não existirem
    cursor.execute('SELECT COUNT(*) FROM estatisticas')
    if cursor.fetchone()[0] == 0:
        estatisticas_iniciais = [
            ('jovens_conectados', 5420),
            ('escolas_participantes', 127),
            ('mentores_voluntarios', 892),
            ('projetos_desenvolvidos', 234),
            ('evasao_reduzida', 30),
            ('aumento_stem', 45)
        ]
        
        cursor.executemany(
            'INSERT INTO estatisticas (metrica, valor) VALUES (?, ?)',
            estatisticas_iniciais
        )
    
    conn.commit()
    conn.close()

# Dados mock para desenvolvimento
ESTATISTICAS_MOCK = {
    "impacto_atual": {
        "jovens_conectados": 5420,
        "escolas_participantes": 127,
        "mentores_voluntarios": 892,
        "projetos_desenvolvidos": 234,
        "meta_2028": 100000
    },
    "indicadores": {
        "evasao_reduzida": 30,
        "aumento_stem": 45,
        "inclusao_periferia": 68,
        "satisfacao_alunos": 94
    },
    "distribuicao_geografica": {
        "sudeste": 45,
        "nordeste": 28,
        "sul": 12,
        "centro_oeste": 10,
        "norte": 5
    }
}

DEPOIMENTOS = [
    {
        "nome": "Maria Silva",
        "idade": 17,
        "cidade": "São Paulo - SP",
        "depoimento": "O ConectaEduca mudou minha vida! Aprendi programação e agora estou desenvolvendo um app para ajudar minha comunidade.",
        "foto": "/api/avatar/maria"
    },
    {
        "nome": "João Santos",
        "idade": 16,
        "cidade": "Recife - PE",
        "depoimento": "Nunca pensei que conseguiria criar um site. Hoje já desenvolvi 3 projetos para resolver problemas da minha escola!",
        "foto": "/api/avatar/joao"
    },
    {
        "nome": "Ana Costa",
        "idade": 18,
        "cidade": "Belém - PA",
        "depoimento": "Graças ao projeto, consegui uma bolsa de estudos em engenharia de software. O futuro chegou até nós!",
        "foto": "/api/avatar/ana"
    }
]

@app.route('/')
def home():
    """Página inicial - redireciona para o HTML"""
    return render_template_string('''
    <!DOCTYPE html>
    <html>
    <head>
        <title>ConectaEduca API</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            .endpoint { background: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 5px; }
            .method { background: #2563eb; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }
        </style>
    </head>
    <body>
        <h1>🚀 ConectaEduca API</h1>
        <p>Backend de apoio para o projeto ConectaEduca - Transformando Exclusão Digital em Inclusão Social</p>
        
        <h2>📊 Endpoints Disponíveis:</h2>
        
        <div class="endpoint">
            <span class="method">GET</span>
            <strong>/api/estatisticas</strong>
            <p>Retorna estatísticas atuais do projeto</p>
        </div>
        
        <div class="endpoint">
            <span class="method">POST</span>
            <strong>/api/interessados</strong>
            <p>Cadastra novo interessado no projeto</p>
        </div>
        
        <div class="endpoint">
            <span class="method">GET</span>
            <strong>/api/depoimentos</strong>
            <p>Lista depoimentos de participantes</p>
        </div>
        
        <div class="endpoint">
            <span class="method">POST</span>
            <strong>/api/eventos</strong>
            <p>Registra evento de analytics</p>
        </div>
        
        <div class="endpoint">
            <span class="method">GET</span>
            <strong>/api/relatorio</strong>
            <p>Gera relatório consolidado do projeto</p>
        </div>
        
        <p><a href="/api/estatisticas">🔗 Ver estatísticas em tempo real</a></p>
    </body>
    </html>
    ''')

@app.route('/api/estatisticas', methods=['GET'])
def get_estatisticas():
    """Retorna estatísticas atuais do projeto"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Buscar estatísticas do banco
        cursor.execute('SELECT metrica, valor FROM estatisticas')
        stats_db = dict(cursor.fetchall())
        
        # Buscar contagem de interessados
        cursor.execute('SELECT COUNT(*) FROM interessados WHERE ativo = TRUE')
        total_interessados = cursor.fetchone()[0]
        
        conn.close()
        
        # Combinar com dados mock
        response_data = {
            "status": "success",
            "data": ESTATISTICAS_MOCK,
            "database_stats": stats_db,
            "total_interessados": total_interessados,
            "ultima_atualizacao": datetime.datetime.now().isoformat()
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e),
            "data": ESTATISTICAS_MOCK  # Fallback para dados mock
        }), 500

@app.route('/api/interessados', methods=['POST'])
def cadastrar_interessado():
    """Cadastra novo interessado no projeto"""
    try:
        dados = request.get_json()
        
        # Validação básica
        required_fields = ['nome', 'email', 'tipo_interesse']
        for field in required_fields:
            if field not in dados or not dados[field]:
                return jsonify({
                    "status": "error",
                    "message": f"Campo '{field}' é obrigatório"
                }), 400
        
        # Validar email
        email = dados['email'].strip().lower()
        if '@' not in email:
            return jsonify({
                "status": "error",
                "message": "Email inválido"
            }), 400
        
        # Inserir no banco
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO interessados (nome, email, tipo_interesse)
                VALUES (?, ?, ?)
            ''', (dados['nome'], email, dados['tipo_interesse']))
            
            interessado_id = cursor.lastrowid
            conn.commit()
            
        except sqlite3.IntegrityError:
            conn.close()
            return jsonify({
                "status": "error",
                "message": "Email já cadastrado"
            }), 409
        
        conn.close()
        
        # Registrar evento
        registrar_evento('novo_interessado', {
            'tipo_interesse': dados['tipo_interesse'],
            'interessado_id': interessado_id
        })
        
        return jsonify({
            "status": "success",
            "message": "Interessado cadastrado com sucesso!",
            "data": {
                "id": interessado_id,
                "nome": dados['nome'],
                "tipo_interesse": dados['tipo_interesse']
            }
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Erro interno: {str(e)}"
        }), 500

@app.route('/api/depoimentos', methods=['GET'])
def get_depoimentos():
    """Retorna depoimentos de participantes"""
    return jsonify({
        "status": "success",
        "data": DEPOIMENTOS,
        "total": len(DEPOIMENTOS)
    })

@app.route('/api/eventos', methods=['POST'])
def registrar_evento_api():
    """Registra evento de analytics"""
    try:
        dados = request.get_json()
        evento = dados.get('evento', 'unknown')
        dados_evento = dados.get('dados', {})
        
        registrar_evento(evento, dados_evento, request.remote_addr)
        
        return jsonify({
            "status": "success",
            "message": "Evento registrado"
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/relatorio', methods=['GET'])
def gerar_relatorio():
    """Gera relatório consolidado do projeto"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Estatísticas de interessados por tipo
        cursor.execute('''
            SELECT tipo_interesse, COUNT(*) 
            FROM interessados 
            WHERE ativo = TRUE 
            GROUP BY tipo_interesse
        ''')
        interessados_por_tipo = dict(cursor.fetchall())
        
        # Eventos mais frequentes (últimos 30 dias)
        cursor.execute('''
            SELECT evento, COUNT(*) 
            FROM eventos 
            WHERE data_evento >= datetime('now', '-30 days')
            GROUP BY evento 
            ORDER BY COUNT(*) DESC 
            LIMIT 10
        ''')
        eventos_frequentes = dict(cursor.fetchall())
        
        # Crescimento mensal de interessados
        cursor.execute('''
            SELECT strftime('%Y-%m', data_cadastro) as mes, COUNT(*) 
            FROM interessados 
            WHERE ativo = TRUE 
            GROUP BY mes 
            ORDER BY mes DESC 
            LIMIT 12
        ''')
        crescimento_mensal = dict(cursor.fetchall())
        
        conn.close()
        
        relatorio = {
            "periodo": {
                "inicio": datetime.datetime.now().replace(day=1).isoformat(),
                "fim": datetime.datetime.now().isoformat()
            },
            "resumo": {
                "total_interessados": sum(interessados_por_tipo.values()),
                "tipos_interesse": interessados_por_tipo,
                "crescimento_mensal": crescimento_mensal,
                "eventos_populares": eventos_frequentes
            },
            "metas_2028": ESTATISTICAS_MOCK["impacto_atual"],
            "indicadores": ESTATISTICAS_MOCK["indicadores"],
            "distribuicao_geografica": ESTATISTICAS_MOCK["distribuicao_geografica"]
        }
        
        return jsonify({
            "status": "success",
            "relatorio": relatorio,
            "gerado_em": datetime.datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/avatar/<nome>')
def get_avatar(nome):
    """Gera avatar simples para depoimentos"""
    # Retorna URL de avatar do Gravatar ou similar
    import hashlib
    hash_nome = hashlib.md5(nome.encode()).hexdigest()
    avatar_url = f"https://www.gravatar.com/avatar/{hash_nome}?d=identicon&s=150"
    
    from flask import redirect
    return redirect(avatar_url)

# Função auxiliar para registrar eventos
def registrar_evento(evento: str, dados: Dict[str, Any] = None, ip: str = None):
    """Registra evento no banco de dados"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO eventos (evento, dados, ip_origem)
            VALUES (?, ?, ?)
        ''', (evento, json.dumps(dados) if dados else None, ip))
        
        conn.commit()
        conn.close()
        
    except Exception as e:
        print(f"Erro ao registrar evento: {e}")

# Função para limpar dados antigos (pode ser executada periodicamente)
def limpar_dados_antigos():
    """Remove eventos antigos para manter o banco leve"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Manter apenas últimos 90 dias de eventos
        cursor.execute('''
            DELETE FROM eventos 
            WHERE data_evento < datetime('now', '-90 days')
        ''')
        
        removidos = cursor.rowcount
        conn.commit()
        conn.close()
        
        print(f"Removidos {removidos} eventos antigos")
        
    except Exception as e:
        print(f"Erro na limpeza: {e}")

# Middleware para logging básico
@app.before_request
def log_request():
    """Log básico de requisições"""
    print(f"{datetime.datetime.now()} - {request.method} {request.path} - {request.remote_addr}")

# Tratamento de erros
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "status": "error",
        "message": "Endpoint não encontrado",
        "codigo": 404
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "status": "error",
        "message": "Erro interno do servidor",
        "codigo": 500
    }), 500

if __name__ == '__main__':
    # Inicializar banco de dados
    init_db()
    
    # Configurar para desenvolvimento
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'
    
    print("🚀 Iniciando ConectaEduca API...")
    print(f"📊 Banco de dados: {DATABASE}")
    print(f"🌐 Servidor: http://localhost:{port}")
    print(f"🔧 Debug: {debug}")
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=debug
    )