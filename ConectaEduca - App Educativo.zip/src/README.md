# 🚀 ConectaEduca - Transformando Exclusão Digital em Inclusão Social

Um projeto educativo completo desenvolvido com HTML, CSS, JavaScript e Python, inspirado nas teorias de Manuel Castells sobre a sociedade em rede.

## 📋 Sobre o Projeto

O ConectaEduca visa transformar escolas em hubs locais de inovação, conectando jovens de periferias e áreas rurais às oportunidades do mundo digital. O projeto aborda:

- **Alfabetização Digital**: Cursos de programação desde o ensino fundamental
- **Mentorias**: Reforço escolar com voluntários qualificados  
- **Equipamentos**: Doação e recondicionamento de computadores
- **Projetos Práticos**: Soluções para problemas reais da comunidade

## 🎯 Objetivos até 2028

- **100 mil** jovens conectados
- **70%** de participantes de periferias e áreas rurais
- **30%** de redução na evasão escolar
- **50%** de aumento na entrada em carreiras STEM

## 🛠️ Tecnologias Utilizadas

### Frontend
- **HTML5**: Estrutura semântica e acessível
- **CSS3**: Design responsivo com sistema de cores laranja/azul
- **JavaScript**: Interatividade, animações e PWA básico
- **Font Awesome**: Ícones vetoriais

### Backend
- **Python 3.8+**: Linguagem principal do backend
- **Flask**: Framework web minimalista
- **SQLite**: Banco de dados local
- **Flask-CORS**: Suporte a requisições cross-origin

## 🚀 Como Executar

### Pré-requisitos
- Python 3.8 ou superior
- Navegador web moderno
- (Opcional) Servidor web local

### Instalação

1. **Clone ou baixe o projeto**
```bash
git clone https://github.com/seu-usuario/conecta-educa.git
cd conecta-educa
```

2. **Instale as dependências Python**
```bash
pip install -r requirements.txt
```

3. **Execute o servidor backend**
```bash
python app.py
```

4. **Abra o frontend**
   - Abra o arquivo `index.html` no navegador, ou
   - Use um servidor local: `python -m http.server 8000`

### URLs de Acesso

- **Frontend**: `http://localhost:8000` (ou abrir `index.html`)
- **Backend API**: `http://localhost:5000`
- **Documentação da API**: `http://localhost:5000`

## 📊 API Endpoints

### GET `/api/estatisticas`
Retorna estatísticas atuais do projeto
```json
{
  "status": "success",
  "data": {
    "impacto_atual": {
      "jovens_conectados": 5420,
      "escolas_participantes": 127,
      "mentores_voluntarios": 892
    }
  }
}
```

### POST `/api/interessados`
Cadastra novo interessado no projeto
```json
{
  "nome": "Maria Silva",
  "email": "maria@email.com",
  "tipo_interesse": "estudante"
}
```

### GET `/api/depoimentos`
Lista depoimentos de participantes

### POST `/api/eventos`
Registra eventos de analytics

### GET `/api/relatorio`
Gera relatório consolidado do projeto

## 🎨 Funcionalidades do Frontend

### Interatividade
- ✅ Animações de scroll
- ✅ Barras de progresso animadas
- ✅ Contadores incrementais
- ✅ Efeito typewriter no título
- ✅ Parallax sutil no hero
- ✅ Modais interativos
- ✅ Sistema de compartilhamento

### Responsividade
- ✅ Design mobile-first
- ✅ Grid flexível
- ✅ Imagens adaptáveis
- ✅ Navegação otimizada

### PWA (Progressive Web App)
- ✅ Service Worker básico
- ✅ Cache offline
- ✅ Analytics local

## 🎯 Funcionalidades do Backend

### Banco de Dados
- ✅ SQLite com inicialização automática
- ✅ Tabelas: interessados, estatisticas, eventos
- ✅ Validação de dados
- ✅ Prevenção de duplicatas

### Analytics
- ✅ Registro de eventos
- ✅ Relatórios consolidados
- ✅ Estatísticas em tempo real
- ✅ Limpeza automática de dados antigos

### Segurança
- ✅ Validação de entrada
- ✅ Rate limiting (opcional)
- ✅ CORS configurado
- ✅ Tratamento de erros

## 🎨 Sistema de Design

### Paleta de Cores
- **Azul Principal**: `#2563eb`
- **Laranja Principal**: `#f97316`
- **Azul Claro**: `#bfdbfe`
- **Laranja Claro**: `#fed7aa`
- **Verde**: `#10b981`
- **Roxo**: `#8b5cf6`

### Tipografia
- **Fonte**: System fonts (Apple/Google/Microsoft)
- **Escalas**: 14px base com escala modular
- **Pesos**: 400 (normal), 500 (medium), 600-700 (títulos)

### Componentes
- Cards com hover effects
- Botões com gradientes
- Badges informativos
- Progress bars animadas
- Modais responsivos

## 📱 Recursos Mobile

- Design responsivo completo
- Touch gestures otimizados
- Performance otimizada
- Offline-first approach
- Web Share API

## 🔧 Desenvolvimento

### Estrutura do Projeto
```
conecta-educa/
├── index.html          # Página principal
├── styles.css          # Estilos globais
├── script.js           # JavaScript principal
├── app.py             # Backend Flask
├── requirements.txt    # Dependências Python
├── README.md          # Documentação
└── conecta_educa.db   # Banco SQLite (criado automaticamente)
```

### Scripts Úteis
```bash
# Executar servidor de desenvolvimento
python app.py

# Executar testes (se implementados)
pytest

# Formatar código Python
black app.py

# Verificar código
flake8 app.py

# Servidor HTTP simples para frontend
python -m http.server 8000
```

## 🌟 Recursos Especiais

### Animações CSS
- Transições suaves
- Keyframes customizados
- Transform 3D
- Backdrop filters

### JavaScript Avançado
- Intersection Observer API
- Web Share API
- Service Workers
- Local Storage analytics

### Python Moderno
- Type hints
- F-strings
- Context managers
- Exception handling

## 🚀 Deploy e Produção

### Frontend
- Pode ser hospedado em qualquer servidor web
- Otimizado para CDN
- Compatível com GitHub Pages, Netlify, Vercel

### Backend
- Compatible com Heroku, Railway, PythonAnywhere
- Variáveis de ambiente configuráveis
- Banco PostgreSQL opcional
- Gunicorn para produção

### Variáveis de Ambiente
```bash
export PORT=5000
export DEBUG=False
export DATABASE_URL=sqlite:///conecta_educa.db
```

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 🙏 Agradecimentos

- Manuel Castells pelas teorias sobre sociedade em rede
- Comunidade open source
- Todos os educadores e mentores voluntários
- Jovens que participam do projeto

## 📞 Contato

- 🌐 **Website**: [conectaeduca.org.br](https://conectaeduca.org.br)
- 📧 **Email**: contato@conectaeduca.org.br
- 📱 **WhatsApp**: (11) 99999-9999
- 🐦 **Twitter**: [@conectaeduca](https://twitter.com/conectaeduca)

---

**ConectaEduca** - *"Nenhum jovem desconectado"* 🚀✨

> "Quem está fora da rede está fora do mundo." - Manuel Castells