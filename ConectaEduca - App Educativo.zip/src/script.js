// Animações e interatividade para o ConectaEduca

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar todas as funcionalidades
    initProgressBars();
    initScrollAnimations();
    initSmoothScroll();
    initCounterAnimations();
    initTypewriterEffect();
    initParallaxEffect();
    
    console.log('ConectaEduca - Sistema carregado com sucesso! 🚀');
});

// Animação das barras de progresso
function initProgressBars() {
    const progressBars = document.querySelectorAll('.progress-fill');
    
    const animateProgressBar = (bar) => {
        const progress = bar.getAttribute('data-progress');
        bar.style.width = '0%';
        
        setTimeout(() => {
            bar.style.width = progress + '%';
        }, 500);
    };
    
    // Observer para animar quando entrar na viewport
    const progressObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateProgressBar(entry.target);
                progressObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    
    progressBars.forEach(bar => {
        progressObserver.observe(bar);
    });
}

// Animações de scroll
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.stat-card, .problem-card, .feature-card, .impact-card, .vision-item, .scenario-item');
    
    const scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                scrollObserver.unobserve(entry.target);
            }
        });
    }, { 
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    // Configurar elementos para animação
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        scrollObserver.observe(element);
    });
}

// Scroll suave para navegação
function initSmoothScroll() {
    // Adicionar navegação suave aos botões "Saiba Mais"
    const smoothScrollButtons = document.querySelectorAll('.btn-outline');
    
    smoothScrollButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const nextSection = button.closest('section').nextElementSibling;
            if (nextSection) {
                nextSection.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Animação de contadores
function initCounterAnimations() {
    const counters = document.querySelectorAll('.impact-number');
    
    const animateCounter = (counter) => {
        const target = counter.textContent;
        const isPercentage = target.includes('%');
        const numericValue = parseInt(target.replace(/\D/g, ''));
        
        let current = 0;
        const increment = numericValue / 60; // 60 frames para 1 segundo
        
        const updateCounter = () => {
            current += increment;
            if (current < numericValue) {
                counter.textContent = Math.floor(current) + (isPercentage ? '%' : 
                    numericValue >= 1000 ? ' mil' : '');
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };
        
        updateCounter();
    };
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    animateCounter(entry.target);
                }, 200);
                counterObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    counters.forEach(counter => {
        counterObserver.observe(counter);
    });
}

// Efeito de digitação no título principal
function initTypewriterEffect() {
    const heroTitle = document.querySelector('.hero-title');
    const originalText = heroTitle.textContent;
    
    // Só executar uma vez quando a página carrega
    heroTitle.textContent = '';
    heroTitle.style.borderRight = '3px solid';
    heroTitle.style.animation = 'blink 1s infinite';
    
    let i = 0;
    const typeWriter = () => {
        if (i < originalText.length) {
            heroTitle.textContent += originalText.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        } else {
            // Remover cursor piscante após terminar
            setTimeout(() => {
                heroTitle.style.borderRight = 'none';
                heroTitle.style.animation = 'none';
            }, 1000);
        }
    };
    
    // Iniciar após um pequeno delay
    setTimeout(typeWriter, 1000);
}

// Efeito parallax sutil no background do hero
function initParallaxEffect() {
    const heroBg = document.querySelector('.hero-bg');
    
    if (!heroBg) return;
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxSpeed = 0.5;
        
        heroBg.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
    });
}

// Adicionar interatividade aos cards
document.addEventListener('click', function(e) {
    // Funcionalidade para botões "Começar Agora"
    if (e.target.classList.contains('btn-primary')) {
        showInterestModal();
    }
    
    // Funcionalidade para o botão final
    if (e.target.closest('.btn-gradient')) {
        showSubscriptionModal();
    }
});

// Modal simples para demonstrar interesse
function showInterestModal() {
    const modal = createModal(
        'Junte-se ao ConectaEduca!',
        `
        <p>Obrigado pelo seu interesse! O ConectaEduca está transformando a educação digital no Brasil.</p>
        <div style="margin: 20px 0;">
            <label style="display: block; margin-bottom: 10px;">
                <input type="radio" name="interesse" value="estudante"> 
                Sou estudante e quero participar
            </label>
            <label style="display: block; margin-bottom: 10px;">
                <input type="radio" name="interesse" value="mentor"> 
                Quero ser mentor voluntário
            </label>
            <label style="display: block; margin-bottom: 10px;">
                <input type="radio" name="interesse" value="escola"> 
                Represento uma escola interessada
            </label>
            <label style="display: block; margin-bottom: 10px;">
                <input type="radio" name="interesse" value="apoiador"> 
                Quero apoiar o projeto
            </label>
        </div>
        <input type="email" placeholder="Seu e-mail" style="width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px;">
        `,
        [
            {
                text: 'Enviar',
                class: 'btn-primary',
                action: () => {
                    alert('Obrigado! Entraremos em contato em breve. 🚀');
                    closeModal();
                }
            },
            {
                text: 'Fechar',
                class: 'btn-outline',
                action: closeModal
            }
        ]
    );
    
    document.body.appendChild(modal);
}

function showSubscriptionModal() {
    const modal = createModal(
        'Fazer Parte da Mudança',
        `
        <p>Juntos podemos transformar a educação digital no Brasil e garantir que nenhum jovem fique desconectado das oportunidades do futuro.</p>
        <div style="margin: 20px 0;">
            <input type="text" placeholder="Nome completo" style="width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px;">
            <input type="email" placeholder="E-mail" style="width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px;">
            <select style="width: 100%; padding: 10px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px;">
                <option value="">Como você pode contribuir?</option>
                <option value="voluntario">Trabalho voluntário</option>
                <option value="doacao">Doação de equipamentos</option>
                <option value="mentoria">Mentoria técnica</option>
                <option value="financeiro">Apoio financeiro</option>
                <option value="parceria">Parceria institucional</option>
            </select>
        </div>
        `,
        [
            {
                text: 'Participar',
                class: 'btn-gradient',
                action: () => {
                    alert('Bem-vindo à rede ConectaEduca! Juntos vamos transformar o futuro da educação! 🌟');
                    closeModal();
                }
            },
            {
                text: 'Cancelar',
                class: 'btn-outline',
                action: closeModal
            }
        ]
    );
    
    document.body.appendChild(modal);
}

// Função para criar modais
function createModal(title, content, buttons) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    `;
    
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        padding: 2rem;
        border-radius: 1rem;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    `;
    
    const modalHeader = document.createElement('h3');
    modalHeader.textContent = title;
    modalHeader.style.cssText = `
        margin-bottom: 1rem;
        color: #1f2937;
        font-size: 1.5rem;
    `;
    
    const modalBody = document.createElement('div');
    modalBody.innerHTML = content;
    
    const modalFooter = document.createElement('div');
    modalFooter.style.cssText = `
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
        margin-top: 2rem;
    `;
    
    buttons.forEach(btn => {
        const button = document.createElement('button');
        button.textContent = btn.text;
        button.className = `btn ${btn.class}`;
        button.onclick = btn.action;
        modalFooter.appendChild(button);
    });
    
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalFooter);
    modal.appendChild(modalContent);
    
    // Fechar modal clicando fora
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    return modal;
}

function closeModal() {
    const modal = document.querySelector('[style*="z-index: 1000"]');
    if (modal) {
        modal.remove();
    }
}

// Adicionar CSS para animação de piscar
const style = document.createElement('style');
style.textContent = `
    @keyframes blink {
        0%, 50% { border-color: transparent; }
        51%, 100% { border-color: #2563eb; }
    }
    
    .modal-enter {
        animation: modalEnter 0.3s ease;
    }
    
    @keyframes modalEnter {
        from {
            opacity: 0;
            transform: scale(0.9);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
`;
document.head.appendChild(style);

// Adicionar funcionalidade offline (PWA básico)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registrado com sucesso:', registration);
            })
            .catch(registrationError => {
                console.log('Falha no registro do SW:', registrationError);
            });
    });
}

// Analytics básico (simulado)
function trackEvent(eventName, eventData = {}) {
    console.log(`📊 Evento: ${eventName}`, eventData);
    
    // Simulação de envio para analytics
    const analyticsData = {
        event: eventName,
        timestamp: new Date().toISOString(),
        page: window.location.pathname,
        ...eventData
    };
    
    // Em uma implementação real, enviaria para Google Analytics, etc.
    localStorage.setItem('conecta_analytics_' + Date.now(), JSON.stringify(analyticsData));
}

// Rastrear interações importantes
document.addEventListener('click', (e) => {
    if (e.target.matches('.btn-primary, .btn-outline, .btn-gradient')) {
        trackEvent('button_click', {
            buttonText: e.target.textContent.trim(),
            buttonClass: e.target.className
        });
    }
});

// Rastrear tempo na página
let pageStartTime = Date.now();
window.addEventListener('beforeunload', () => {
    const timeOnPage = Math.round((Date.now() - pageStartTime) / 1000);
    trackEvent('page_view_duration', { seconds: timeOnPage });
});

// Feedback visual melhorado para interações
document.addEventListener('mouseenter', (e) => {
    if (e.target.matches('.stat-card, .feature-card, .impact-card, .vision-item')) {
        e.target.style.transform = 'translateY(-8px) scale(1.02)';
    }
});

document.addEventListener('mouseleave', (e) => {
    if (e.target.matches('.stat-card, .feature-card, .impact-card, .vision-item')) {
        e.target.style.transform = 'translateY(0) scale(1)';
    }
});

// Funcionalidade de compartilhamento
function shareProject() {
    if (navigator.share) {
        navigator.share({
            title: 'ConectaEduca - Transformando Exclusão Digital em Inclusão Social',
            text: 'Conheça o projeto que está transformando a educação digital no Brasil!',
            url: window.location.href
        });
    } else {
        // Fallback para navegadores sem Web Share API
        const shareUrl = encodeURIComponent(window.location.href);
        const shareText = encodeURIComponent('Conheça o ConectaEduca - projeto que transforma exclusão digital em inclusão social!');
        
        const shareOptions = {
            'WhatsApp': `https://wa.me/?text=${shareText}%20${shareUrl}`,
            'Twitter': `https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}`,
            'Facebook': `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`,
            'LinkedIn': `https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`
        };
        
        // Criar modal de compartilhamento
        const shareModal = createModal(
            'Compartilhar ConectaEduca',
            `
            <p>Ajude a espalhar a palavra sobre o ConectaEduca!</p>
            <div style="display: flex; flex-wrap: wrap; gap: 10px; margin: 20px 0;">
                ${Object.entries(shareOptions).map(([platform, url]) => 
                    `<a href="${url}" target="_blank" style="padding: 10px 15px; background: var(--primary-blue); color: white; text-decoration: none; border-radius: 5px; font-size: 14px;">${platform}</a>`
                ).join('')}
            </div>
            `,
            [
                {
                    text: 'Fechar',
                    class: 'btn-outline',
                    action: closeModal
                }
            ]
        );
        
        document.body.appendChild(shareModal);
    }
}

// Adicionar botão de compartilhamento (opcional)
const heroButtons = document.querySelector('.hero-buttons');
if (heroButtons) {
    const shareButton = document.createElement('button');
    shareButton.className = 'btn btn-outline';
    shareButton.innerHTML = '<i class="fas fa-share-alt"></i> Compartilhar';
    shareButton.onclick = shareProject;
    heroButtons.appendChild(shareButton);
}