import { Toaster } from "./components/ui/sonner";
import { NavigationBar } from "./components/NavigationBar";
import { HeroSection } from "./components/HeroSection";
import { ProblemSection } from "./components/ProblemSection";
import { SolutionSection } from "./components/SolutionSection";
import { ImpactSection } from "./components/ImpactSection";
import { FutureSection } from "./components/FutureSection";
import { useEffect } from "react";

export default function App() {
  useEffect(() => {
    // Smooth scroll behavior para toda a aplicação
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Analytics básico - rastrear carregamento da página
    console.log('🚀 ConectaEduca carregado com sucesso!');
    
    // Simular analytics
    const startTime = Date.now();
    
    return () => {
      const timeSpent = Date.now() - startTime;
      console.log(`📊 Tempo na página: ${Math.round(timeSpent / 1000)}s`);
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Sistema de Navegação */}
      <NavigationBar />
      
      {/* Conteúdo Principal */}
      <main>
        <div id="hero">
          <HeroSection />
        </div>
        
        <div id="problem-section">
          <ProblemSection />
        </div>
        
        <div id="solution-section">
          <SolutionSection />
        </div>
        
        <div id="impact-section">
          <ImpactSection />
        </div>
        
        <div id="future-section">
          <FutureSection />
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-orange-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">CE</span>
                </div>
                <span className="text-xl font-bold">ConectaEduca</span>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                Transformando exclusão digital em inclusão social através da educação e inovação. 
                Inspirado nas teorias de Manuel Castells sobre a sociedade em rede.
              </p>
              <div className="flex items-center gap-4">
                <div className="text-sm text-gray-400">
                  <strong className="text-blue-400">5.420</strong> jovens conectados
                </div>
                <div className="text-sm text-gray-400">
                  <strong className="text-orange-400">127</strong> escolas participantes
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#hero" className="hover:text-white transition-colors">Início</a></li>
                <li><a href="#problem-section" className="hover:text-white transition-colors">O Problema</a></li>
                <li><a href="#solution-section" className="hover:text-white transition-colors">Nossa Solução</a></li>
                <li><a href="#impact-section" className="hover:text-white transition-colors">Impacto</a></li>
                <li><a href="#future-section" className="hover:text-white transition-colors">Visão de Futuro</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>📧 contato@conectaeduca.org.br</li>
                <li>📱 (11) 99999-9999</li>
                <li>🌐 www.conectaeduca.org.br</li>
                <li>📍 São Paulo - SP</li>
              </ul>
              
              <div className="mt-4">
                <h5 className="font-medium mb-2">Redes Sociais</h5>
                <div className="flex gap-2">
                  <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                    <span className="text-xs">f</span>
                  </div>
                  <div className="w-8 h-8 bg-blue-400 rounded flex items-center justify-center cursor-pointer hover:bg-blue-500 transition-colors">
                    <span className="text-xs">t</span>
                  </div>
                  <div className="w-8 h-8 bg-blue-700 rounded flex items-center justify-center cursor-pointer hover:bg-blue-800 transition-colors">
                    <span className="text-xs">in</span>
                  </div>
                  <div className="w-8 h-8 bg-green-500 rounded flex items-center justify-center cursor-pointer hover:bg-green-600 transition-colors">
                    <span className="text-xs">📱</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 ConectaEduca. Todos os direitos reservados. 
              <span className="ml-2">Projeto Social Punk para Inclusão Digital</span>
            </div>
            
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>Inspirado por Manuel Castells</span>
              <span>•</span>
              <span>Made with ❤️ for Brazil</span>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Sistema de Notificações */}
      <Toaster 
        position="bottom-right"
        expand={true}
        richColors
        closeButton
        toastOptions={{
          duration: 4000,
          style: {
            background: 'white',
            border: '1px solid #e2e8f0',
            boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
          }
        }}
      />
    </div>
  );
}