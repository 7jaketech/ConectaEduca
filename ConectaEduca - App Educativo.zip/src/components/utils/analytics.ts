// Sistema de Analytics simples para ConectaEduca
export interface AnalyticsEvent {
  event: string;
  properties?: Record<string, any>;
  timestamp?: number;
}

class ConectaEducaAnalytics {
  private events: AnalyticsEvent[] = [];
  private sessionId: string;
  private startTime: number;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.startTime = Date.now();
    this.trackPageView();
  }

  private generateSessionId(): string {
    return 'ce_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  }

  public track(event: string, properties?: Record<string, any>): void {
    const analyticsEvent: AnalyticsEvent = {
      event,
      properties: {
        ...properties,
        sessionId: this.sessionId,
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: Date.now()
      },
      timestamp: Date.now()
    };

    this.events.push(analyticsEvent);
    
    // Salvar no localStorage para persistência
    this.saveToStorage(analyticsEvent);
    
    // Log para desenvolvimento
    console.log('📊 Analytics:', analyticsEvent);
  }

  public trackPageView(): void {
    this.track('page_view', {
      page: window.location.pathname,
      title: document.title,
      referrer: document.referrer
    });
  }

  public trackButton(buttonText: string, section?: string): void {
    this.track('button_click', {
      buttonText,
      section: section || this.getCurrentSection()
    });
  }

  public trackSection(sectionName: string): void {
    this.track('section_view', {
      section: sectionName,
      timeOnPage: Date.now() - this.startTime
    });
  }

  public trackFormSubmit(formType: string, success: boolean): void {
    this.track('form_submit', {
      formType,
      success,
      timeToSubmit: Date.now() - this.startTime
    });
  }

  public trackEngagement(): void {
    const timeOnPage = Date.now() - this.startTime;
    const scrollDepth = this.getScrollDepth();
    
    this.track('engagement', {
      timeOnPage,
      scrollDepth,
      sectionsViewed: this.getSectionsViewed()
    });
  }

  private getCurrentSection(): string {
    const sections = ['hero', 'problem-section', 'solution-section', 'impact-section', 'future-section'];
    
    for (const section of sections) {
      const element = document.getElementById(section);
      if (element) {
        const rect = element.getBoundingClientRect();
        if (rect.top <= 100 && rect.bottom >= 100) {
          return section;
        }
      }
    }
    
    return 'unknown';
  }

  private getScrollDepth(): number {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
    return Math.round((scrollTop / documentHeight) * 100);
  }

  private getSectionsViewed(): string[] {
    const viewedSections = this.events
      .filter(event => event.event === 'section_view')
      .map(event => event.properties?.section)
      .filter(Boolean);
    
    return [...new Set(viewedSections)];
  }

  private saveToStorage(event: AnalyticsEvent): void {
    try {
      const stored = localStorage.getItem('conecta_analytics') || '[]';
      const events = JSON.parse(stored);
      events.push(event);
      
      // Manter apenas os últimos 100 eventos
      if (events.length > 100) {
        events.splice(0, events.length - 100);
      }
      
      localStorage.setItem('conecta_analytics', JSON.stringify(events));
    } catch (error) {
      console.warn('Erro ao salvar analytics:', error);
    }
  }

  public getReport(): any {
    const timeOnPage = Date.now() - this.startTime;
    const scrollDepth = this.getScrollDepth();
    
    return {
      sessionId: this.sessionId,
      timeOnPage,
      scrollDepth,
      eventsCount: this.events.length,
      sectionsViewed: this.getSectionsViewed(),
      lastEvents: this.events.slice(-10),
      userInfo: {
        userAgent: navigator.userAgent,
        language: navigator.language,
        platform: navigator.platform,
        screenResolution: `${screen.width}x${screen.height}`,
        viewportSize: `${window.innerWidth}x${window.innerHeight}`
      }
    };
  }
}

// Instância global
export const analytics = new ConectaEducaAnalytics();

// Event listeners automáticos
document.addEventListener('DOMContentLoaded', () => {
  // Rastrear cliques em botões
  document.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;
    if (target.tagName === 'BUTTON' || target.closest('button')) {
      const button = target.tagName === 'BUTTON' ? target : target.closest('button');
      analytics.trackButton(button?.textContent?.trim() || 'Unknown Button');
    }
  });

  // Rastrear scroll para seções
  let currentSection = '';
  const handleScroll = () => {
    const newSection = analytics['getCurrentSection']();
    if (newSection !== currentSection && newSection !== 'unknown') {
      currentSection = newSection;
      analytics.trackSection(newSection);
    }
  };

  window.addEventListener('scroll', handleScroll);

  // Rastrear engajamento antes de sair da página
  window.addEventListener('beforeunload', () => {
    analytics.trackEngagement();
  });

  // Rastrear tempo na página a cada 30 segundos
  setInterval(() => {
    analytics.trackEngagement();
  }, 30000);
});

// Funções auxiliares para componentes React
export const trackUserInteraction = (action: string, details?: any) => {
  analytics.track('user_interaction', { action, ...details });
};

export const trackFeatureUsage = (feature: string, context?: any) => {
  analytics.track('feature_usage', { feature, ...context });
};

export const trackError = (error: string, context?: any) => {
  analytics.track('error', { error, ...context });
};