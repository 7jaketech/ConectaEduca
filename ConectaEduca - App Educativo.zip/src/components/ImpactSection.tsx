import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { Users, MapPin, GraduationCap, TrendingUp, Calendar, Target } from "lucide-react";

export function ImpactSection() {
  const stats = [
    {
      icon: Users,
      value: "100 mil",
      label: "Jovens Conectados",
      description: "Alcance total do programa até 2028",
      progress: 100,
      color: "blue"
    },
    {
      icon: MapPin,
      value: "70%",
      label: "Inclusão",
      description: "Participantes vindos de periferias urbanas e zonas rurais",
      progress: 70,
      color: "orange"
    },
    {
      icon: GraduationCap,
      value: "30%",
      label: "Redução",
      description: "Na evasão escolar em escolas participantes",
      progress: 30,
      color: "green"
    },
    {
      icon: TrendingUp,
      value: "50%",
      label: "Aumento",
      description: "Na entrada desses jovens em carreiras STEM",
      progress: 50,
      color: "purple"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-100 to-orange-100 rounded-full px-4 py-2 mb-6">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span className="text-sm">Impacto Esperado até 2028</span>
          </div>
          
          <h2 className="text-3xl md:text-4xl mb-6">
            <span className="text-gradient">Transformando Vidas</span> através da Educação Digital
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossos objetivos são ambiciosos, mas realistas. Cada jovem conectado é uma vida transformada.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="p-8 hover:shadow-lg transition-all duration-300 hover:scale-[1.02]">
              <div className="flex items-start gap-4 mb-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'orange' ? 'bg-orange-100' :
                  stat.color === 'green' ? 'bg-green-100' : 'bg-purple-100'
                }`}>
                  <stat.icon className={`w-8 h-8 ${
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'orange' ? 'text-orange-600' :
                    stat.color === 'green' ? 'text-green-600' : 'text-purple-600'
                  }`} />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className={`text-4xl font-bold ${
                      stat.color === 'blue' ? 'text-blue-600' :
                      stat.color === 'orange' ? 'text-orange-600' :
                      stat.color === 'green' ? 'text-green-600' : 'text-purple-600'
                    }`}>
                      {stat.value}
                    </span>
                    <span className="text-lg text-gray-600">{stat.label}</span>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{stat.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Progresso</span>
                      <span>{stat.progress}%</span>
                    </div>
                    <Progress 
                      value={stat.progress} 
                      className={`h-2 ${
                        stat.color === 'blue' ? '[&>div]:bg-blue-600' :
                        stat.color === 'orange' ? '[&>div]:bg-orange-600' :
                        stat.color === 'green' ? '[&>div]:bg-green-600' : '[&>div]:bg-purple-600'
                      }`}
                    />
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="bg-gradient-to-br from-blue-600 to-orange-600 rounded-2xl p-8 text-white text-center">
          <Target className="w-12 h-12 mx-auto mb-6 opacity-90" />
          <h3 className="text-2xl md:text-3xl mb-4">Nossa Meta</h3>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Construir um Brasil onde a educação ensina a pensar, criar e resolver problemas, 
            não apenas decorar fórmulas, transformando a classe trabalhadora em um 
            <strong> "proletariado 2.0"</strong> capaz de programar, automatizar e operar no novo mundo digital.
          </p>
        </div>
      </div>
    </section>
  );
}