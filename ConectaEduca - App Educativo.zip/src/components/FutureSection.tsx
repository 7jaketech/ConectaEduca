import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ArrowRight, Cpu, BookOpen, Lightbulb, Users, Factory, Rocket, Globe } from "lucide-react";

export function FutureSection() {
  const currentScenario = [
    {
      icon: Factory,
      title: "Dependência de commodities",
      description: "Economia baseada em produtos primários"
    },
    {
      icon: Globe,
      title: "Consumidor de tecnologia estrangeira", 
      description: "Importamos a maior parte da tecnologia que usamos"
    },
    {
      icon: Users,
      title: "Desigualdade digital acentuada",
      description: "Grande parte da população sem acesso adequado"
    }
  ];
  
  const futureScenario = [
    {
      icon: Rocket,
      title: "Produtor global de inovação",
      description: "Brasil como referência em desenvolvimento tecnológico"
    },
    {
      icon: Cpu,
      title: "Criador de soluções tecnológicas",
      description: "Desenvolvemos nossas próprias tecnologias"
    },
    {
      icon: Users,
      title: "Inclusão digital como base",
      description: "Redução das desigualdades através da tecnologia"
    }
  ];
  
  const visionItems = [
    { icon: Cpu, label: "Produzir", color: "blue" },
    { icon: Users, label: "Capacitar", color: "orange" },
    { icon: BookOpen, label: "Aprender", color: "green" },
    { icon: Lightbulb, label: "Criar", color: "purple" },
    { icon: Users, label: "Refletir", color: "pink" }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-orange-100 text-orange-800 hover:bg-orange-200">
            Visão 2030+
          </Badge>
          <h2 className="text-3xl md:text-4xl mb-6">
            <span className="text-gradient">Visão de Futuro</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Um Brasil transformado pela educação digital, onde cada jovem é um agente de mudança.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-16">
          {visionItems.map((item, index) => (
            <Card key={index} className={`p-6 text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${
              item.color === 'blue' ? 'border-blue-200 hover:border-blue-300' :
              item.color === 'orange' ? 'border-orange-200 hover:border-orange-300' :
              item.color === 'green' ? 'border-green-200 hover:border-green-300' :
              item.color === 'purple' ? 'border-purple-200 hover:border-purple-300' :
              'border-pink-200 hover:border-pink-300'
            }`}>
              <div className={`w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center ${
                item.color === 'blue' ? 'bg-blue-100' :
                item.color === 'orange' ? 'bg-orange-100' :
                item.color === 'green' ? 'bg-green-100' :
                item.color === 'purple' ? 'bg-purple-100' :
                'bg-pink-100'
              }`}>
                <item.icon className={`w-6 h-6 ${
                  item.color === 'blue' ? 'text-blue-600' :
                  item.color === 'orange' ? 'text-orange-600' :
                  item.color === 'green' ? 'text-green-600' :
                  item.color === 'purple' ? 'text-purple-600' :
                  'text-pink-600'
                }`} />
              </div>
              <p className="font-medium">{item.label}</p>
            </Card>
          ))}
        </div>
        
        <div className="mb-16">
          <h3 className="text-2xl md:text-3xl text-center mb-12">
            Brasil: De Consumidor a <span className="text-gradient">Produtor de Inovação</span>
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h4 className="text-xl mb-6 text-red-600">Cenário Atual</h4>
              <div className="space-y-4">
                {currentScenario.map((item, index) => (
                  <Card key={index} className="p-6 bg-red-50 border-red-200">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <item.icon className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h5 className="mb-2 text-red-800">{item.title}</h5>
                        <p className="text-red-700 text-sm">{item.description}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-xl mb-6 text-green-600">Futuro Possível</h4>
              <div className="space-y-4">
                {futureScenario.map((item, index) => (
                  <Card key={index} className="p-6 bg-green-50 border-green-200">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <item.icon className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h5 className="mb-2 text-green-800">{item.title}</h5>
                        <p className="text-green-700 text-sm">{item.description}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-2xl p-8 text-center">
          <h3 className="text-2xl md:text-3xl mb-6">
            Conclusão: <span className="text-gradient">Nenhum Jovem Desconectado</span>
          </h3>
          
          <blockquote className="text-xl md:text-2xl text-gray-800 italic mb-6 max-w-3xl mx-auto">
            "Quem está fora da rede está fora do mundo."
          </blockquote>
          <p className="text-gray-600 mb-2">— Manuel Castells</p>
          
          <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-orange-50 rounded-xl">
            <p className="text-lg text-gray-700 mb-6 max-w-4xl mx-auto">
              Com o ConectaEduca, queremos transformar exclusão digital em inclusão social, 
              aproximando o Brasil de um futuro mais justo, inovador e democrático. 
              Nosso desafio é garantir que nenhum jovem brasileiro continue desconectado 
              das oportunidades que a era digital proporciona.
            </p>
            
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-orange-600 hover:from-blue-700 hover:to-orange-700">
              Fazer Parte da Mudança
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}