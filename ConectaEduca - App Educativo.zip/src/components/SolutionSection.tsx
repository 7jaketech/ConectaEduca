import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { BookOpen, Users2, Computer, Lightbulb, Rocket, Target, PlayCircle, Star, Code, Zap } from "lucide-react";
import { useState, useEffect } from "react";

export function SolutionSection() {
  const [activeFeature, setActiveFeature] = useState(0);
  const [studentProgress, setStudentProgress] = useState(0);
  
  const features = [
    {
      icon: BookOpen,
      title: "Alfabetização Digital",
      description: "Cursos de alfabetização digital, lógica e programação desde o ensino fundamental.",
      color: "blue",
      details: {
        modules: ["Lógica de Programação", "HTML & CSS", "JavaScript Básico", "Python para Iniciantes"],
        duration: "6 meses",
        students: 2400,
        completion: 87
      }
    },
    {
      icon: Users2,
      title: "Mentorias",
      description: "Reforço escolar e mentorias com universitários e profissionais voluntários.",
      color: "orange",
      details: {
        modules: ["Mentoria Individual", "Grupos de Estudo", "Orientação Profissional", "Projetos Práticos"],
        duration: "Contínuo",
        students: 1800,
        completion: 92
      }
    },
    {
      icon: Computer,
      title: "Equipamentos",
      description: "Doação e recondicionamento de computadores e celulares.",
      color: "green",
      details: {
        modules: ["Recondicionamento", "Doação", "Manutenção", "Treinamento Técnico"],
        duration: "Permanente",
        students: 3200,
        completion: 78
      }
    },
    {
      icon: Lightbulb,
      title: "Projetos Práticos",
      description: "Projetos que resolvem problemas reais da comunidade (água, lixo, mobilidade, segurança).",
      color: "purple",
      details: {
        modules: ["Ideação", "Desenvolvimento", "Teste", "Implementação"],
        duration: "3-6 meses",
        students: 960,
        completion: 85
      }
    }
  ];
  
  const successStories = [
    {
      name: "Maria Silva",
      age: 17,
      city: "São Paulo - SP",
      story: "Desenvolveu um app para monitorar a qualidade da água na comunidade",
      achievement: "Ganhou prêmio de inovação social",
      avatar: "MS",
      progress: 95
    },
    {
      name: "João Santos", 
      age: 16,
      city: "Recife - PE",
      story: "Criou sistema de gestão para biblioteca escolar",
      achievement: "Bolsa integral em Ciência da Computação",
      avatar: "JS",
      progress: 88
    },
    {
      name: "Ana Costa",
      age: 18,
      city: "Belém - PA", 
      story: "Desenvolveu plataforma para conectar produtores locais",
      achievement: "Startup reconhecida pelo governo",
      avatar: "AC",
      progress: 92
    }
  ];

  const ods = [
    {
      number: "4",
      title: "Educação de Qualidade",
      description: "Garantir educação inclusiva, equitativa e de qualidade, promovendo oportunidades de aprendizagem ao longo da vida para todos.",
      color: "blue",
      progress: 75,
      actions: ["Capacitação de professores", "Laboratórios digitais", "Material didático interativo"]
    },
    {
      number: "10", 
      title: "Redução das Desigualdades",
      description: "Reduzir as desigualdades dentro dos países e entre eles, promovendo inclusão econômica, social e política de todos.",
      color: "orange",
      progress: 68,
      actions: ["Acesso à tecnologia", "Bolsas de estudo", "Mentorias gratuitas"]
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % features.length);
    }, 6000);
    
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Animação do progresso do estudante
    const timer = setTimeout(() => {
      setStudentProgress(87);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const ProjectDemo = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Code className="w-5 h-5 text-blue-600" />
        <span className="text-sm text-gray-600">Demonstração: App de Monitoramento Ambiental</span>
      </div>
      
      <div className="bg-gray-900 rounded-lg p-4 text-green-400 font-mono text-sm">
        <div className="mb-2">$ python sensor_agua.py</div>
        <div className="text-yellow-400">Iniciando monitoramento...</div>
        <div>pH: 7.2 ✓</div>
        <div>Turbidez: 0.8 NTU ✓</div>
        <div>Temperatura: 22°C ✓</div>
        <div className="text-green-300 mt-2">✅ Água dentro dos padrões</div>
        <div className="text-blue-300">📊 Dados enviados para dashboard</div>
      </div>
      
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-green-50 p-2 rounded">
          <div className="text-green-600">124</div>
          <div className="text-xs text-gray-600">Sensores Ativos</div>
        </div>
        <div className="bg-blue-50 p-2 rounded">
          <div className="text-blue-600">87%</div>
          <div className="text-xs text-gray-600">Qualidade Média</div>
        </div>
        <div className="bg-orange-50 p-2 rounded">
          <div className="text-orange-600">15</div>
          <div className="text-xs text-gray-600">Alertas Hoje</div>
        </div>
      </div>
    </div>
  );

  return (
    <section id="solution-section" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
            Social Punk
          </Badge>
          <h2 className="text-3xl md:text-4xl mb-6">
            ConectaEduca: <span className="text-gradient">Uma Rede de Educação Digital</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Inspirados pela teoria de Castells, transformamos escolas em hubs locais de inovação.
          </p>
        </div>
        
        {/* Features interativas */}
        <div className="mb-16">
          <Tabs value={activeFeature.toString()} onValueChange={(value) => setActiveFeature(parseInt(value))}>
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-8">
              {features.map((feature, index) => (
                <TabsTrigger key={index} value={index.toString()} className="flex items-center gap-2">
                  <feature.icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{feature.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>
            
            {features.map((feature, index) => (
              <TabsContent key={index} value={index.toString()}>
                <Card className="p-8">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          feature.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                          feature.color === 'orange' ? 'bg-orange-100 text-orange-600' :
                          feature.color === 'green' ? 'bg-green-100 text-green-600' : 
                          'bg-purple-100 text-purple-600'
                        }`}>
                          <feature.icon className="w-6 h-6" />
                        </div>
                        <h3 className="text-2xl">{feature.title}</h3>
                      </div>
                      
                      <p className="text-gray-600 mb-6">{feature.description}</p>
                      
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Duração do programa</span>
                          <span className="text-sm">{feature.details.duration}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Estudantes ativos</span>
                          <span className="text-sm">{feature.details.students.toLocaleString()}</span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Taxa de conclusão</span>
                            <span className="text-sm">{feature.details.completion}%</span>
                          </div>
                          <Progress 
                            value={feature.details.completion} 
                            className={`h-2 ${
                              feature.color === 'blue' ? '[&>div]:bg-blue-500' :
                              feature.color === 'orange' ? '[&>div]:bg-orange-500' :
                              feature.color === 'green' ? '[&>div]:bg-green-500' : 
                              '[&>div]:bg-purple-500'
                            }`}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="mb-4">Módulos do Programa</h4>
                      <div className="space-y-2 mb-6">
                        {feature.details.modules.map((module, idx) => (
                          <div key={idx} className="flex items-center gap-2 p-2 bg-white rounded border">
                            <Star className="w-4 h-4 text-yellow-500" />
                            <span className="text-sm">{module}</span>
                          </div>
                        ))}
                      </div>
                      
                      {feature.title === "Projetos Práticos" && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" className="w-full">
                              <PlayCircle className="w-4 h-4 mr-2" />
                              Ver Demonstração
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Projeto em Ação</DialogTitle>
                            </DialogHeader>
                            <ProjectDemo />
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </div>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
        
        {/* Histórias de sucesso */}
        <div className="mb-16">
          <h3 className="text-2xl md:text-3xl text-center mb-8">Histórias de Transformação</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {successStories.map((story, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <Avatar>
                    <AvatarFallback className="bg-blue-100 text-blue-600">
                      {story.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h5 className="font-medium">{story.name}, {story.age}</h5>
                    <p className="text-xs text-gray-600">{story.city}</p>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-3 text-sm">{story.story}</p>
                
                <div className="bg-green-50 rounded-lg p-3 mb-4">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-green-600" />
                    <span className="text-green-800 text-sm">{story.achievement}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-600">Progresso no programa</span>
                    <span className="text-xs">{story.progress}%</span>
                  </div>
                  <Progress value={story.progress} className="h-1 [&>div]:bg-green-500" />
                </div>
              </Card>
            ))}
          </div>
        </div>
        
        {/* De Usuários a Criadores */}
        <div className="bg-white rounded-2xl p-8 mb-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl mb-4">De Usuários a Criadores</h3>
            <p className="text-lg text-gray-600 max-w-4xl mx-auto">
              <strong>Ideia central:</strong> Jovens deixam de ser apenas usuários de tecnologia 
              e passam a ser criadores de soluções para problemas reais de suas comunidades.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            {[
              { icon: Target, label: "Empoderar", color: "blue" },
              { icon: Lightbulb, label: "Criar", color: "orange" },
              { icon: Rocket, label: "Inovar", color: "green" },
              { icon: Users2, label: "Colaborar", color: "purple" },
              { icon: BookOpen, label: "Aprender", color: "pink" }
            ].map((item, index) => (
              <div key={index} className="text-center group cursor-pointer">
                <div className={`w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center transition-transform group-hover:scale-110 ${
                  item.color === 'blue' ? 'bg-blue-50 text-blue-600 group-hover:bg-blue-100' :
                  item.color === 'orange' ? 'bg-orange-50 text-orange-600 group-hover:bg-orange-100' :
                  item.color === 'green' ? 'bg-green-50 text-green-600 group-hover:bg-green-100' :
                  item.color === 'purple' ? 'bg-purple-50 text-purple-600 group-hover:bg-purple-100' :
                  'bg-pink-50 text-pink-600 group-hover:bg-pink-100'
                }`}>
                  <item.icon className="w-8 h-8" />
                </div>
                <p className="text-sm font-medium">{item.label}</p>
              </div>
            ))}
          </div>
          
          {/* Simulador de progresso do estudante */}
          <div className="bg-gray-50 rounded-xl p-6">
            <h4 className="mb-4">Jornada do Estudante ConectaEduca</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Progresso Geral</span>
                <span className="text-sm">{studentProgress}%</span>
              </div>
              <Progress value={studentProgress} className="h-3 [&>div]:bg-gradient-to-r [&>div]:from-blue-500 [&>div]:to-orange-500" />
              
              <div className="grid grid-cols-4 gap-2 text-xs text-center mt-4">
                <div className="space-y-1">
                  <div className="w-8 h-8 bg-green-500 rounded-full mx-auto flex items-center justify-center text-white">✓</div>
                  <div>Alfabetização</div>
                </div>
                <div className="space-y-1">
                  <div className="w-8 h-8 bg-green-500 rounded-full mx-auto flex items-center justify-center text-white">✓</div>
                  <div>Mentoria</div>
                </div>
                <div className="space-y-1">
                  <div className="w-8 h-8 bg-blue-500 rounded-full mx-auto flex items-center justify-center text-white">3</div>
                  <div>Projetos</div>
                </div>
                <div className="space-y-1">
                  <div className="w-8 h-8 bg-gray-300 rounded-full mx-auto flex items-center justify-center text-gray-600">4</div>
                  <div>Certificação</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* ODS Section */}
        <div>
          <h3 className="text-2xl md:text-3xl text-center mb-12">
            Conexão com os <span className="text-gradient">Objetivos de Desenvolvimento Sustentável</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {ods.map((item, index) => (
              <Card key={index} className={`p-8 ${
                item.color === 'blue' ? 'bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200' :
                'bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200'
              }`}>
                <div className="flex items-start gap-4 mb-6">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl text-white ${
                    item.color === 'blue' ? 'bg-blue-600' : 'bg-orange-600'
                  }`}>
                    {item.number}
                  </div>
                  <div className="flex-1">
                    <h4 className={`mb-3 ${
                      item.color === 'blue' ? 'text-blue-800' : 'text-orange-800'
                    }`}>
                      ODS {item.number} - {item.title}
                    </h4>
                    <p className={`mb-4 ${
                      item.color === 'blue' ? 'text-blue-700' : 'text-orange-700'
                    }`}>
                      {item.description}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Progresso nas metas</span>
                    <span className="text-sm">{item.progress}%</span>
                  </div>
                  <Progress 
                    value={item.progress} 
                    className={`h-2 ${
                      item.color === 'blue' ? '[&>div]:bg-blue-500' : '[&>div]:bg-orange-500'
                    }`}
                  />
                  
                  <div className="space-y-2">
                    <h6 className="text-sm font-medium">Principais ações:</h6>
                    {item.actions.map((action, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          item.color === 'blue' ? 'bg-blue-500' : 'bg-orange-500'
                        }`} />
                        <span className="text-sm">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}