import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Progress } from "./ui/progress";
import { Menu, X, Home, AlertTriangle, Lightbulb, TrendingUp, Rocket, Phone, MapPin } from "lucide-react";

export function NavigationBar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  const navItems = [
    { id: 'hero', label: 'Início', icon: Home },
    { id: 'problem-section', label: 'Problema', icon: AlertTriangle },
    { id: 'solution-section', label: 'Solução', icon: Lightbulb },
    { id: 'impact-section', label: 'Impacto', icon: TrendingUp },
    { id: 'future-section', label: 'Futuro', icon: Rocket },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      // Detectar seção ativa
      const sections = navItems.map(item => item.id);
      const currentSection = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      
      if (currentSection) {
        setActiveSection(currentSection);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  const ContactDialog = () => (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Phone className="w-5 h-5 text-blue-600" />
          Entre em Contato
        </DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
          <MapPin className="w-5 h-5 text-blue-600" />
          <div>
            <p className="font-medium text-blue-800">Sede Nacional</p>
            <p className="text-sm text-blue-600">São Paulo - SP</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 text-center">
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">127</p>
            <p className="text-xs text-gray-600">Escolas Participantes</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-orange-600">892</p>
            <p className="text-xs text-gray-600">Mentores Ativos</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <p className="text-sm text-gray-600">📧 contato@conectaeduca.org.br</p>
          <p className="text-sm text-gray-600">📱 (11) 99999-9999</p>
          <p className="text-sm text-gray-600">🌐 www.conectaeduca.org.br</p>
        </div>
        
        <div className="bg-gradient-to-r from-blue-50 to-orange-50 p-4 rounded-lg">
          <p className="text-sm text-center text-gray-700">
            <strong>Horário de atendimento:</strong><br />
            Segunda a sexta: 8h às 18h<br />
            Sábado: 9h às 13h
          </p>
        </div>
      </div>
    </DialogContent>
  );

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200' 
        : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => scrollToSection('hero')}
          >
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-orange-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">CE</span>
            </div>
            <span className="text-xl font-bold text-gradient">ConectaEduca</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                    activeSection === item.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <IconComponent className="w-4 h-4" />
                  {item.label}
                </button>
              );
            })}
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="ml-4">
                  <Phone className="w-4 h-4 mr-2" />
                  Contato
                </Button>
              </DialogTrigger>
              <ContactDialog />
            </Dialog>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white rounded-lg shadow-lg border border-gray-200 mt-2">
              {navItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`flex items-center gap-3 w-full px-3 py-2 rounded-lg text-sm transition-colors ${
                      activeSection === item.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    {item.label}
                  </button>
                );
              })}
              
              <div className="pt-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full">
                      <Phone className="w-4 h-4 mr-2" />
                      Contato
                    </Button>
                  </DialogTrigger>
                  <ContactDialog />
                </Dialog>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Progress Indicator */}
      {scrolled && (
        <div className="absolute bottom-0 left-0 right-0">
          <Progress 
            value={Math.min((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100, 100)}
            className="h-1 [&>div]:bg-gradient-to-r [&>div]:from-blue-600 [&>div]:to-orange-600"
          />
        </div>
      )}
    </nav>
  );
}