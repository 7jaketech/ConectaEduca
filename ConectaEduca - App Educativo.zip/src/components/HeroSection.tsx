import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { toast } from "sonner@2.0.3";
import { Wifi, Users, Target, TrendingUp, ArrowRight, Play, Heart } from "lucide-react";
import { useState, useEffect } from "react";

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStat, setCurrentStat] = useState(0);
  
  const stats = [
    { icon: Users, value: "100 mil", label: "Jovens Conectados até 2028", color: "blue" },
    { icon: Target, value: "70%", label: "De participantes de periferias e áreas rurais", color: "orange" },
    { icon: TrendingUp, value: "50%", label: "Aumento na entrada em carreiras STEM", color: "green" }
  ];

  useEffect(() => {
    setIsVisible(true);
    
    // Rotação automática das estatísticas
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length);
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSubscribe = async (formData: FormData) => {
    const data = {
      nome: formData.get('nome'),
      email: formData.get('email'),
      tipo_interesse: formData.get('tipo_interesse')
    };

    try {
      // Simular chamada à API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success("🚀 Cadastro realizado com sucesso!", {
        description: "Entraremos em contato em breve para começar sua jornada no ConectaEduca."
      });
    } catch (error) {
      toast.error("Erro ao realizar cadastro. Tente novamente.");
    }
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-orange-50 min-h-screen flex items-center">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))]" />
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse" />
      <div className="absolute bottom-32 right-16 w-32 h-32 bg-orange-200 rounded-full opacity-20 animate-bounce" style={{ animationDuration: '3s' }} />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className={`text-center mb-16 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <Badge className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 mb-6 border border-orange-200 hover:border-orange-300 transition-colors">
            <Wifi className="w-4 h-4 text-blue-600" />
            <span className="text-sm text-gray-700">Transformando Exclusão Digital em Inclusão Social</span>
          </Badge>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl mb-6 text-gradient max-w-5xl mx-auto animate-pulse">
            ConectaEduca
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
            Inspirado nas teorias de <strong>Manuel Castells</strong> sobre a sociedade em rede, 
            transformamos escolas em hubs locais de inovação digital.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 group">
                  Começar Agora
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Heart className="w-5 h-5 text-red-500" />
                    Junte-se ao ConectaEduca!
                  </DialogTitle>
                </DialogHeader>
                <form action={handleSubscribe} className="space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome completo</Label>
                    <Input 
                      id="nome" 
                      name="nome" 
                      placeholder="Seu nome completo" 
                      required 
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">E-mail</Label>
                    <Input 
                      id="email" 
                      name="email" 
                      type="email" 
                      placeholder="seu@email.com" 
                      required 
                    />
                  </div>
                  <div>
                    <Label htmlFor="tipo_interesse">Como você pode contribuir?</Label>
                    <Select name="tipo_interesse" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma opção" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="estudante">Sou estudante e quero participar</SelectItem>
                        <SelectItem value="mentor">Quero ser mentor voluntário</SelectItem>
                        <SelectItem value="escola">Represento uma escola interessada</SelectItem>
                        <SelectItem value="apoiador">Quero apoiar o projeto</SelectItem>
                        <SelectItem value="doador">Posso doar equipamentos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-orange-600 hover:from-blue-700 hover:to-orange-700">
                    Fazer Parte da Mudança
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
            
            <Button 
              variant="outline" 
              size="lg" 
              className="border-orange-300 text-orange-600 hover:bg-orange-50 group"
              onClick={() => scrollToSection('problem-section')}
            >
              <Play className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
              Saiba Mais
            </Button>
          </div>
          
          {/* Quote inspiracional */}
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 max-w-2xl mx-auto border border-blue-100">
            <blockquote className="text-lg italic text-gray-700 mb-2">
              "Quem está fora da rede está fora do mundo."
            </blockquote>
            <cite className="text-sm text-gray-500">— Manuel Castells</cite>
          </div>
        </div>
        
        {/* Estatísticas em cards rotativos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            const isActive = index === currentStat;
            
            return (
              <Card 
                key={index}
                className={`p-6 transition-all duration-500 cursor-pointer group hover:scale-105 ${
                  isActive 
                    ? 'bg-white shadow-xl border-2 border-blue-300 transform scale-105' 
                    : 'bg-white/70 backdrop-blur-sm border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => setCurrentStat(index)}
              >
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-colors ${
                  stat.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                  stat.color === 'orange' ? 'bg-orange-100 text-orange-600' :
                  'bg-green-100 text-green-600'
                }`}>
                  <IconComponent className="w-6 h-6" />
                </div>
                <h3 className={`mb-2 transition-colors ${
                  isActive ? 'text-blue-600' : 'text-gray-800'
                }`}>
                  {stat.value}
                </h3>
                <p className={`transition-colors ${
                  isActive ? 'text-blue-500' : 'text-gray-600'
                }`}>
                  {stat.label}
                </p>
                
                {/* Indicator de progresso */}
                <div className="mt-4 h-1 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${
                      stat.color === 'blue' ? 'bg-blue-500' :
                      stat.color === 'orange' ? 'bg-orange-500' :
                      'bg-green-500'
                    }`}
                    style={{ 
                      width: isActive ? '100%' : '0%',
                      transitionDelay: isActive ? '0ms' : '300ms'
                    }}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}