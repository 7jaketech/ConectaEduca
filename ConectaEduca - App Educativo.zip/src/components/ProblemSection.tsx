import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { AlertTriangle, WifiOff, Repeat, TrendingDown, Users, GraduationCap } from "lucide-react";
import { useState, useEffect } from "react";

export function ProblemSection() {
  const [visibleCards, setVisibleCards] = useState(new Set());
  const [selectedProblem, setSelectedProblem] = useState(0);
  
  const problems = [
    {
      icon: AlertTriangle,
      title: "Educação Desatualizada",
      description: "As escolas brasileiras ainda ensinam como se estivéssemos no século XX, mas os desafios são do século XXI.",
      impact: 85,
      stat: "85% das escolas não têm laboratórios de informática funcionais",
      color: "red"
    },
    {
      icon: WifiOff,
      title: "Exclusão das Redes",
      description: "Jovens de periferias e áreas rurais estão fora das redes de poder e inovação.",
      impact: 72,
      stat: "72% dos jovens em áreas rurais não têm acesso à internet de qualidade",
      color: "orange"
    },
    {
      icon: Repeat,
      title: "Ciclo de Desigualdade",
      description: "A exclusão digital reforça o ciclo da desigualdade social, econômica e cultural.",
      impact: 68,
      stat: "68% das vagas em tecnologia são ocupadas por pessoas de classe alta",
      color: "gray"
    }
  ];

  const inequalities = [
    { icon: Users, label: "Acesso à Internet", value: 45, total: 100 },
    { icon: GraduationCap, label: "Educação Digital", value: 23, total: 100 },
    { icon: TrendingDown, label: "Oportunidades STEM", value: 31, total: 100 }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = entry.target.getAttribute('data-index');
            if (index) {
              setVisibleCards(prev => new Set([...prev, parseInt(index)]));
            }
          }
        });
      },
      { threshold: 0.3 }
    );

    const cards = document.querySelectorAll('[data-index]');
    cards.forEach(card => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setSelectedProblem((prev) => (prev + 1) % problems.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="problem-section" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-red-100 text-red-800 hover:bg-red-200">
            O Problema
          </Badge>
          <h2 className="text-3xl md:text-4xl mb-6">
            O Contexto da <span className="text-gradient">Sociedade em Rede</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Segundo Manuel Castells, vivemos numa sociedade onde o acesso à tecnologia 
            determina as oportunidades de vida.
          </p>
        </div>
        
        {/* Estatísticas da desigualdade digital */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {inequalities.map((item, index) => {
            const IconComponent = item.icon;
            const isVisible = visibleCards.has(index);
            
            return (
              <Card 
                key={index}
                data-index={index}
                className={`p-6 text-center transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <IconComponent className="w-8 h-8 text-red-500 mx-auto mb-4" />
                <h4 className="mb-3">{item.label}</h4>
                <div className="text-3xl text-red-600 mb-2">
                  {item.value}%
                </div>
                <p className="text-sm text-gray-600 mb-4">das periferias sem acesso adequado</p>
                <Progress 
                  value={isVisible ? item.value : 0} 
                  className="h-2 [&>div]:bg-red-500"
                />
              </Card>
            );
          })}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <Card className="p-8 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-blue-800">Acesso = Oportunidade</h3>
            </div>
            <p className="text-blue-700 mb-4">
              Quem tem acesso à informação e à tecnologia pode aprender, criar, 
              empreender e participar das grandes decisões sociais, políticas e econômicas.
            </p>
            <div className="bg-blue-200 rounded-lg p-3">
              <span className="text-blue-800 text-sm">
                💡 Cada jovem conectado representa uma família com mais oportunidades
              </span>
            </div>
          </Card>
          
          <Card className="p-8 bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-orange-800">Exclusão = Nova Desigualdade</h3>
            </div>
            <p className="text-orange-700 mb-4">
              Quem fica de fora das redes digitais está excluído das principais 
              oportunidades de trabalho, renda e participação cidadã.
            </p>
            <div className="bg-orange-200 rounded-lg p-3">
              <span className="text-orange-800 text-sm">
                ⚠️ A cada dia de exclusão digital, a distância social aumenta
              </span>
            </div>
          </Card>
        </div>
        
        <div className="bg-gradient-to-r from-orange-100 to-blue-100 rounded-2xl p-8 text-center mb-16">
          <blockquote className="text-2xl md:text-3xl text-gray-800 italic mb-4">
            "A exclusão tecnológica é a nova forma de exclusão social."
          </blockquote>
          <p className="text-gray-600">— Manuel Castells</p>
        </div>
        
        {/* Problemas interativos */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-12">
            <h3 className="text-2xl md:text-3xl">O Problema Central</h3>
            <div className="flex gap-2">
              {problems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedProblem(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === selectedProblem ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {problems.map((problem, index) => {
              const IconComponent = problem.icon;
              const isSelected = index === selectedProblem;
              
              return (
                <Card 
                  key={index}
                  className={`p-6 text-center cursor-pointer transition-all duration-500 ${
                    isSelected 
                      ? `transform scale-105 shadow-xl border-2 ${
                          problem.color === 'red' ? 'border-red-400 bg-red-50' :
                          problem.color === 'orange' ? 'border-orange-400 bg-orange-50' :
                          'border-gray-400 bg-gray-50'
                        }`
                      : 'hover:shadow-lg border-gray-200'
                  }`}
                  onClick={() => setSelectedProblem(index)}
                >
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-colors ${
                    problem.color === 'red' ? 'bg-red-600 text-white' :
                    problem.color === 'orange' ? 'bg-orange-600 text-white' :
                    'bg-gray-600 text-white'
                  }`}>
                    <IconComponent className="w-8 h-8" />
                  </div>
                  
                  <h4 className={`mb-3 transition-colors ${
                    problem.color === 'red' ? 'text-red-800' :
                    problem.color === 'orange' ? 'text-orange-800' :
                    'text-gray-800'
                  }`}>
                    {problem.title}
                  </h4>
                  
                  <p className={`mb-4 transition-colors ${
                    problem.color === 'red' ? 'text-red-700' :
                    problem.color === 'orange' ? 'text-orange-700' :
                    'text-gray-700'
                  }`}>
                    {problem.description}
                  </p>
                  
                  {isSelected && (
                    <div className="space-y-3 animate-fadeIn">
                      <div className={`bg-white rounded-lg p-3 border ${
                        problem.color === 'red' ? 'border-red-200' :
                        problem.color === 'orange' ? 'border-orange-200' :
                        'border-gray-200'
                      }`}>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm">Impacto</span>
                          <span className="text-sm">{problem.impact}%</span>
                        </div>
                        <Progress 
                          value={problem.impact} 
                          className={`h-2 ${
                            problem.color === 'red' ? '[&>div]:bg-red-500' :
                            problem.color === 'orange' ? '[&>div]:bg-orange-500' :
                            '[&>div]:bg-gray-500'
                          }`}
                        />
                      </div>
                      <p className="text-xs text-gray-600 italic">
                        {problem.stat}
                      </p>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
        
        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl p-8">
            <h4 className="text-xl mb-4">É hora de agir!</h4>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Cada dia que passa sem ação é mais um dia de jovens perdendo oportunidades. 
              O ConectaEduca oferece a solução que o Brasil precisa.
            </p>
            <Button 
              className="bg-gradient-to-r from-blue-600 to-orange-600 hover:from-blue-700 hover:to-orange-700"
              onClick={() => {
                const element = document.getElementById('solution-section');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Ver a Solução
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}