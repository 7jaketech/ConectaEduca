import { useEffect, useCallback } from 'react';
import { analytics, trackUserInteraction, trackFeatureUsage, trackError } from '../utils/analytics';

export function useAnalytics() {
  // Rastrear montagem do componente
  useEffect(() => {
    const componentName = new Error().stack
      ?.split('\n')[2]
      ?.match(/at (\w+)/)?.[1] || 'Unknown';
    
    analytics.track('component_mount', { componentName });
    
    return () => {
      analytics.track('component_unmount', { componentName });
    };
  }, []);

  const trackClick = useCallback((elementName: string, context?: any) => {
    trackUserInteraction('click', { elementName, ...context });
  }, []);

  const trackView = useCallback((viewName: string, context?: any) => {
    trackUserInteraction('view', { viewName, ...context });
  }, []);

  const trackFeature = useCallback((featureName: string, context?: any) => {
    trackFeatureUsage(featureName, context);
  }, []);

  const trackFormSubmit = useCallback((formName: string, success: boolean, context?: any) => {
    analytics.trackFormSubmit(formName, success);
    if (context) {
      trackUserInteraction('form_submit', { formName, success, ...context });
    }
  }, []);

  const trackDownload = useCallback((fileName: string, fileType: string) => {
    trackUserInteraction('download', { fileName, fileType });
  }, []);

  const trackShare = useCallback((platform: string, content: string) => {
    trackUserInteraction('share', { platform, content });
  }, []);

  const trackError = useCallback((errorMessage: string, context?: any) => {
    trackError(errorMessage, context);
  }, []);

  return {
    trackClick,
    trackView,
    trackFeature,
    trackFormSubmit,
    trackDownload,
    trackShare,
    trackError,
    getReport: analytics.getReport.bind(analytics)
  };
}

// Hook para rastrear tempo em seção
export function useSectionTracking(sectionName: string) {
  useEffect(() => {
    const startTime = Date.now();
    
    analytics.trackSection(sectionName);
    
    return () => {
      const timeSpent = Date.now() - startTime;
      analytics.track('section_time', { 
        section: sectionName, 
        timeSpent 
      });
    };
  }, [sectionName]);
}

// Hook para rastrear performance
export function usePerformanceTracking() {
  useEffect(() => {
    // Rastrear métricas de performance quando disponível
    if (typeof window !== 'undefined' && 'performance' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          analytics.track('performance_metric', {
            name: entry.name,
            duration: entry.duration,
            startTime: entry.startTime,
            entryType: entry.entryType
          });
        }
      });

      observer.observe({ entryTypes: ['measure', 'mark', 'navigation'] });

      return () => observer.disconnect();
    }
  }, []);
}

// Hook para rastrear erros de JavaScript
export function useErrorTracking() {
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      trackError('javascript_error', {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack
      });
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      trackError('unhandled_promise_rejection', {
        reason: event.reason
      });
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);
}

// Hook para rastrear visibilidade da página
export function useVisibilityTracking() {
  useEffect(() => {
    const handleVisibilityChange = () => {
      analytics.track('visibility_change', {
        visible: !document.hidden,
        timestamp: Date.now()
      });
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
}